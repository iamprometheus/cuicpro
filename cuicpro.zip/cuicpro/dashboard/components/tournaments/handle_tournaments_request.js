jQuery(document).on("click", "#delete-tournament-button", function () {
	const tournamentID = jQuery(this).data("tournament-id");

	jQuery.ajax({
		type: "POST",
		url: cuicpro.ajax_url,
		data: {
			action: "delete_tournament",
			tournament_id: tournamentID,
		},
		success: function (response) {
			if (response.success) {
				jQuery("#tournament-data").html(response.data.html);

				let days = [];

				jQuery("#tournament-days")
					.multiDatesPicker({
						minDate: 0,
						dateFormat: "d/m/y",
						onSelect: function (dateText, inst) {
							days = inst.input.val().split(",");
							jQuery("#hours-container").empty();
							for (let i = 0; i < days.length; i++) {
								jQuery("#hours-container").append(
									`<div class='hours-slider'>
										<label for='hours-range-${i}'>${days[i]}</label>
										<input type='text' id='hours-range-${i}' readonly style='border:0; color:#f6931f; font-weight:bold;'>
										<div id='slider-hours-${i}' class='tournament-slider'></div>
									</div>`,
								);
							}
						},
					})
					.blur(function () {
						for (let i = 0; i < days.length; i++) {
							jQuery(`#slider-hours-${i}`).slider({
								range: true,
								min: 7,
								max: 23,
								step: 1,
								values: [8, 20], // Initial values (8 AM to 5 PM)
								slide: function (event, ui) {
									const startHour =
										(ui.values[0] < 10 ? "0" : "") + ui.values[0];
									const endHour = (ui.values[1] < 10 ? "0" : "") + ui.values[1];
									jQuery(`#hours-range-${i}`).val(
										startHour + ":00 - " + endHour + ":00",
									);
								},
							});

							const initialStartHour =
								(jQuery(`#slider-hours-${i}`).slider("values", 0) < 10
									? "0"
									: "") + jQuery(`#slider-hours-${i}`).slider("values", 0);
							const initialEndHour =
								(jQuery(`#slider-hours-${i}`).slider("values", 1) < 10
									? "0"
									: "") + jQuery(`#slider-hours-${i}`).slider("values", 1);
							jQuery(`#hours-range-${i}`).val(
								initialStartHour + ":00 - " + initialEndHour + ":00",
							);
						}
					});

				jQuery("#tournament-selected-days").multiDatesPicker({
					minDate: 0,
					dateFormat: "d/m/y",
				});

				jQuery("#official-schedule").multiDatesPicker({
					minDate: 0,
					dateFormat: "d/m/y",
				});

				jQuery("#slider-hours").slider({
					range: true,
					min: 7,
					max: 23,
					step: 1,
					values: [8, 20], // Initial values (8 AM to 5 PM)
					slide: function (event, ui) {
						const startHour = (ui.values[0] < 10 ? "0" : "") + ui.values[0];
						const endHour = (ui.values[1] < 10 ? "0" : "") + ui.values[1];
						jQuery("#hours-range").val(startHour + ":00 - " + endHour + ":00");
					},
				});

				jQuery("#slider-fields-5v5").slider({
					range: true,
					min: 1,
					max: 12,
					step: 1,
					values: [1, 8], // Initial values (8 AM to 5 PM)
					slide: function (event, ui) {
						const startField = (ui.values[0] < 10 ? "0" : "") + ui.values[0];
						const endField = (ui.values[1] < 10 ? "0" : "") + ui.values[1];
						jQuery("#fields-5v5-range").val(startField + " - " + endField);
					},
				});

				const initialStartField5v5 =
					(jQuery("#slider-fields-5v5").slider("values", 0) < 10 ? "0" : "") +
					jQuery("#slider-fields-5v5").slider("values", 0);
				const initialEndField5v5 =
					(jQuery("#slider-fields-5v5").slider("values", 1) < 10 ? "0" : "") +
					jQuery("#slider-fields-5v5").slider("values", 1);
				jQuery("#fields-5v5-range").val(
					initialStartField5v5 + " - " + initialEndField5v5,
				);

				jQuery("#slider-fields-7v7").slider({
					range: true,
					min: 1,
					max: 12,
					step: 1,
					values: [9, 12], // Initial values (8 AM to 5 PM)
					slide: function (event, ui) {
						const startField = (ui.values[0] < 10 ? "0" : "") + ui.values[0];
						const endField = (ui.values[1] < 10 ? "0" : "") + ui.values[1];
						jQuery("#fields-7v7-range").val(startField + " - " + endField);
					},
				});

				const initialStartField7v7 =
					(jQuery("#slider-fields-7v7").slider("values", 0) < 10 ? "0" : "") +
					jQuery("#slider-fields-7v7").slider("values", 0);
				const initialEndField7v7 =
					(jQuery("#slider-fields-7v7").slider("values", 1) < 10 ? "0" : "") +
					jQuery("#slider-fields-7v7").slider("values", 1);
				jQuery("#fields-7v7-range").val(
					initialStartField7v7 + " - " + initialEndField7v7,
				);

				jQuery("#tournament-result-table")
					.removeClass("error")
					.addClass("success")
					.html(response.data.message);
			} else {
				jQuery("#tournament-result-table")
					.removeClass("success")
					.addClass("error")
					.html(response.data.message);
			}
		},
		error: function (xhr, status, error) {
			console.error("Error:", error);
		},
	});
});

jQuery(document).on("click", "#add-tournament-button", function (e) {
	e.preventDefault();

	const tournamentName = jQuery("#tournament-name").val();
	const tournamentDays =
		jQuery("#tournament-days").multiDatesPicker("getDates");

	const tournamentHours = [];
	jQuery("#hours-container")
		.children()
		.each(function (index) {
			const tournamentHoursStart = jQuery(`#slider-hours-${index}`).slider(
				"values",
				0,
			);
			const tournamentHoursEnd = jQuery(`#slider-hours-${index}`).slider(
				"values",
				1,
			);
			tournamentHours.push([tournamentHoursStart, tournamentHoursEnd]);
		});

	const tournamentFields5v5Start = jQuery("#slider-fields-5v5").slider(
		"values",
		0,
	);
	const tournamentFields5v5End = jQuery("#slider-fields-5v5").slider(
		"values",
		1,
	);
	const tournamentFields7v7Start = jQuery("#slider-fields-7v7").slider(
		"values",
		0,
	);
	const tournamentFields7v7End = jQuery("#slider-fields-7v7").slider(
		"values",
		1,
	);

	if (tournamentName === "") {
		jQuery("#tournament-result-table")
			.removeClass("success")
			.addClass("error")
			.html("Agregar Nombre");
		return;
	}

	if (tournamentDays.length === 0) {
		jQuery("#tournament-result-table")
			.removeClass("success")
			.addClass("error")
			.html("Agregar Dias");
		return;
	}

	jQuery.ajax({
		type: "POST",
		url: cuicpro.ajax_url,
		data: {
			action: "add_tournament",
			tournament_name: tournamentName,
			tournament_days: tournamentDays.join(","),
			tournament_hours: tournamentHours,
			tournament_fields_5v5_start: tournamentFields5v5Start,
			tournament_fields_5v5_end: tournamentFields5v5End,
			tournament_fields_7v7_start: tournamentFields7v7Start,
			tournament_fields_7v7_end: tournamentFields7v7End,
		},
		success: function (response) {
			console.log(response);
			if (response.success) {
				const tournamentData = document.querySelector("#tournament-data");
				tournamentData.innerHTML = response.data.html;

				jQuery("#tournament-result-table")
					.removeClass("error")
					.addClass("success")
					.html(response.data.message);
			}
		},
		error: function (xhr, status, error) {
			console.error("Error:", error);
		},
	});
});

jQuery(document).on("click", "#create-brackets-button", function (e) {
	e.preventDefault();
	const tournamentID = jQuery(this).data("tournament-id");

	jQuery.ajax({
		type: "POST",
		url: cuicpro.ajax_url,
		data: {
			action: "create_brackets",
			tournament_id: tournamentID,
		},
		success: function (response) {
			if (response.success) {
				jQuery("#create-brackets-button").attr("disabled", true);
				jQuery("#delete-brackets-button").attr("disabled", false);
				jQuery("#assign-officials-button").attr("disabled", false);

				jQuery("#tournament-result-table")
					.removeClass("error")
					.addClass("success")
					.html(response.data.message);
			} else {
				jQuery("#tournament-result-table")
					.removeClass("success")
					.addClass("error")
					.html(response.data.message);
			}
		},
		error: function (xhr, status, error) {
			console.error("Error:", error);
		},
	});
});

jQuery(document).on("click", "#delete-brackets-button", function (e) {
	e.preventDefault();
	const tournamentID = jQuery(this).data("tournament-id");

	jQuery.ajax({
		type: "POST",
		url: cuicpro.ajax_url,
		data: {
			action: "delete_brackets",
			tournament_id: tournamentID,
		},
		success: function (response) {
			if (response.success) {
				jQuery("#brackets-data").html("");
				jQuery("#brackets-dropdown").html("");
				jQuery("#brackets-dropdown").append(
					"<option value=''>Seleccionar Bracket</option>",
				);

				jQuery("#create-brackets-button").attr("disabled", false);
				jQuery("#assign-officials-button").attr("disabled", true);
				jQuery("#delete-brackets-button").attr("disabled", true);

				jQuery("#tournament-result-table")
					.removeClass("error")
					.addClass("success")
					.html(response.data.message);
			} else {
				jQuery("#tournament-result-table")
					.removeClass("success")
					.addClass("error")
					.html(response.data.message);
			}
		},
		error: function (xhr, status, error) {
			console.error("Error:", error);
		},
	});
});

jQuery(document).on("click", "#assign-officials-button", function (e) {
	e.preventDefault();
	const tournamentID = jQuery(this).data("tournament-id");

	jQuery.ajax({
		type: "POST",
		url: cuicpro.ajax_url,
		data: {
			action: "assign_officials",
			tournament_id: tournamentID,
		},
		success: function (response) {
			if (response.success) {
				jQuery("#assign-officials-button").attr("disabled", true);
				jQuery("#tournament-result-table")
					.removeClass("error")
					.addClass("success")
					.html(response.data.message);
			} else {
				jQuery("#tournament-result-table")
					.removeClass("success")
					.addClass("error")
					.html(response.data.message);
			}
		},
		error: function (xhr, status, error) {
			console.error("Error:", error);
		},
	});
});
