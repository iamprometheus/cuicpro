jQuery(document).on("click", "#add-coach-button", function (e) {
	e.preventDefault();

	const coachName = jQuery("#coach-name-cv").val();
	const coachContact = jQuery("#coach-contact-cv").val();
	const coachCity = jQuery("#coach-city-cv").val();
	const coachState = jQuery("#coach-state-cv").val();
	const coachCountry = jQuery("#coach-country-cv").val();

	if (coachName === "") {
		alert("Agregar un nombre al entrenador");
		return;
	}

	if (coachContact === "") {
		alert("Agregar el contacto al entrenador");
		return;
	}

	jQuery.ajax({
		type: "POST",
		url: cuicpro.ajax_url,
		data: {
			action: "add_coach",
			coach_name: coachName,
			coach_contact: coachContact,
			coach_city: coachCity,
			coach_state: coachState,
			coach_country: coachCountry,
		},
		success: function (response) {
			console.log(response);
			if (response.success) {
				// add coach to the table

				jQuery("#coaches-data").append(`
					<div class="table-row" id="coach-${response.data.coach.coach_id}">
						<span class="table-cell">${response.data.coach.coach_name}</span>
						<span class="table-cell">${response.data.coach.coach_contact}</span>
						<span class="table-cell">${response.data.coach.coach_city}</span>
						<span class="table-cell">${response.data.coach.coach_state}</span>
						<span class="table-cell">${response.data.coach.coach_country}</span>
						<div class="table-cell">
							<button id="edit-coach-button" data-coach-id="${response.data.coach.coach_id}">Editar</button>
							<button id="delete-coach-button" data-coach-id="${response.data.coach.coach_id}">Eliminar</button>
						</div>
					</div>
				`);

				const inputName = jQuery("#coach-name-cv");
				inputName.val("");
				const inputContact = jQuery("#coach-contact-cv");
				inputContact.val("");
				const inputCity = jQuery("#coach-city-cv");
				inputCity.val("");
				const inputState = jQuery("#coach-state-cv");
				inputState.val("");
				const inputCountry = jQuery("#coach-country-cv");
				inputCountry.val("");

				// update coaches dropdown from team by league viewer
				const dropdown = jQuery("#team-coach-ta");
				if (dropdown) {
					dropdown.append(
						`<option value="${response.data.coach.coach_id}">${response.data.coach.coach_name}</option>`,
					);
				}

				// update coaches dropdown from teams by coach viewer
				const dropdown2 = jQuery("#coaches-dropdown-tv");
				dropdown2.append(
					`<option value="${response.data.coach.coach_id}">${response.data.coach.coach_name}</option>`,
				);

				jQuery("#coach-result-table")
					.removeClass("error")
					.addClass("success")
					.html(response.data.message);
			} else {
				jQuery("#coach-result-table")
					.removeClass("success")
					.addClass("error")
					.html(response.data.message);
			}
		},
		error: function (xhr, status, error) {
			console.error("Error:", error);
		},
	});
});

jQuery(document).on("click", "#delete-coach-button", function () {
	const coachID = jQuery(this).data("coach-id");

	jQuery.ajax({
		type: "POST",
		url: cuicpro.ajax_url,
		data: {
			action: "delete_coach",
			coach_id: coachID,
		},
		success: function (response) {
			console.log(response);
			if (response.success) {
				const parent = document
					.querySelector(`#coach-${coachID}`)
					.closest("div");
				parent.remove();

				// remove option from teams by league viewer dropdown
				const dropdown = document.querySelector("#team-coach-ta");
				if (dropdown) {
					dropdown.querySelector(`option[value="${coachID}"]`).remove();
				}

				// remove option from teams by coach viewer dropdown
				const dropdown2 = document.querySelector("#coaches-dropdown-tv");
				dropdown2.querySelector(`option[value="${coachID}"]`).remove();
				const element = document.querySelector("#coach-data");
				element.innerHTML = "";

				jQuery("#coach-result-table")
					.removeClass("error")
					.addClass("success")
					.html(response.data.message);
			} else {
				jQuery("#coach-result-table")
					.removeClass("success")
					.addClass("error")
					.html(response.data.message);
			}
		},
		error: function (xhr, status, error) {
			console.error("Error:", error);
		},
	});
});
