<?php

function create_bracket_match($match) {
  $team_1_name = "TBD";
  $team_2_name = "TBD";

  if ($match->team_id_1) {
    $team_1_name = TeamsDatabase::get_team_by_id($match->team_id_1)->team_name;
  }

  if ($match->team_id_2) {
    $team_2_name = TeamsDatabase::get_team_by_id($match->team_id_2)->team_name;
  }

  $official = OfficialsDatabase::get_official_by_id($match->official_id);
  $official_name = $official ? $official->official_name : "Asignacion Pendiente";

  $match_time = $match->match_time . ":00";

  if ($match->match_link_1) {
    $previous_match_info = PendingMatchesDatabase::get_match_by_bracket_match($match->match_link_1, $match->bracket_id);
    $selected_1 = $match->team_id_1 != null && $match->team_id_1 == $previous_match_info->team_id_1 ? "selected" : "";
    $selected_2 = $match->team_id_1 != null && $match->team_id_1 == $previous_match_info->team_id_2 ? "selected" : "";

    $team_1_name = "<select id='team-winner' data-match-id='" . $match->match_id . "' data-prev-match='" . $previous_match_info->match_id . "' data-team-number='1' >";
    $team_1_name .= "<option value='0'>Seleccionar Ganador</option>";
    $team_1_name .= "<option value='" . $previous_match_info->team_id_1 . "' $selected_1>" . TeamsDatabase::get_team_by_id($previous_match_info->team_id_1)->team_name . "</option>";
    $team_1_name .= "<option value='" . $previous_match_info->team_id_2 . "' $selected_2>" . TeamsDatabase::get_team_by_id($previous_match_info->team_id_2)->team_name . "</option>";
    $team_1_name .= "</select>";
  } 

  if ($match->match_link_2) {
    $previous_match_info = PendingMatchesDatabase::get_match_by_bracket_match($match->match_link_2, $match->bracket_id);
    $selected_1 = $match->team_id_2 != null && $match->team_id_2 == $previous_match_info->team_id_1 ? "selected" : "";
    $selected_2 = $match->team_id_2 != null && $match->team_id_2 == $previous_match_info->team_id_2 ? "selected" : "";

    $team_2_name = "<select id='team-winner' data-match-id='" . $match->match_id . "' data-prev-match='" . $previous_match_info->match_id . "' data-team-number='2' >";
    $team_2_name .= "<option value='0'>Seleccionar Ganador</option>";
    $team_2_name .= "<option value='" . $previous_match_info->team_id_1 . "' $selected_1>" . TeamsDatabase::get_team_by_id($previous_match_info->team_id_1)->team_name . "</option>";
    $team_2_name .= "<option value='" . $previous_match_info->team_id_2 . "' $selected_2>" . TeamsDatabase::get_team_by_id($previous_match_info->team_id_2)->team_name . "</option>";
    $team_2_name .= "</select>";
  }

  $html = "<div class='bracket-match'>";
  $html .= "<span>" . $team_1_name . "</span>";
  $html .= "<span>VS</span>";
  $html .= "<span>" . $team_2_name . "</span>";
  $html .= "</div>";
  $html .= "<div class='match-data-container'>";
  $html .= "<div class='match-data'>";
  $html .= "<span>Fecha: " . $match->match_date . "</span>";
  $html .= "<span>Hora: " . $match_time . "</span>";
  $html .= "</div>";
  $html .= "<div class='match-data text-right'>";
  $html .= "<span>Arbitro: " . $official_name . "</span>";
  $html .= "<span>Campo: " . $match->field_number . "</span>";
  $html .= "</div>";
  $html .= "</div>";
  return $html;
}

function on_fetch_bracket_data(int $bracket_id) {
  $matches = PendingMatchesDatabase::get_matches_by_bracket($bracket_id);

  $bracket_rounds = array_unique(array_map(function($match) {
    return $match->bracket_round;
  }, $matches));

  $html = "<div class='bracket-container'>";
  $elements = [];
  foreach ($bracket_rounds as $round) {
    $html .= "<div id='round_" . $round . "' class='bracket-round'>";

    $elements[$round] = [];
    foreach ($matches as $match) {
      if ($match->bracket_round == $round) {
        $previous_match_1 = $match->match_link_1;
        $previous_match_2 = $match->match_link_2;

        if ($previous_match_1) {
          $previous_match_1_info = PendingMatchesDatabase::get_match_by_bracket_match($previous_match_1, $match->bracket_id);
          $elements[$round]["match_" . $match->match_id][] = "match_" . $previous_match_1_info->match_id;
        }

        if ($previous_match_2) {
          $previous_match_2_info = PendingMatchesDatabase::get_match_by_bracket_match($previous_match_2, $match->bracket_id);
          $elements[$round]["match_" . $match->match_id][] = "match_" . $previous_match_2_info->match_id;
        }

        $html .= "<div id='match_" . $match->match_id . "' class='bracket-match-container'>";
        $html .= create_bracket_match($match);
        $html .= "</div>";
      }
    }
    $html .= "</div>";
  }

  $html .= "</div>";
  return ['html' => $html, 'elements' => $elements, 'matches' => $matches];
}

function fetch_bracket_data() {
  if (!isset($_POST['bracket_id'])) {
    wp_send_json_error(['message' => 'Faltan datos']);
  }

  $bracket_id = intval($_POST['bracket_id']);

  wp_send_json_success(['message' => 'Bracket recuperado correctamente', 'html' => on_fetch_bracket_data($bracket_id)['html'], 'elements' => on_fetch_bracket_data($bracket_id)['elements'], 'matches' => on_fetch_bracket_data($bracket_id)['matches']]);
}

function update_match_winner() {
  if (!isset($_POST['match_id']) || !isset($_POST['team_id']) || !isset($_POST['prev_match_id']) || !isset($_POST['team_number'])) {
    wp_send_json_error(['message' => 'Faltan datos']);
  }

  $match_id = intval($_POST['match_id']);
  $team_id = intval($_POST['team_id']);
  $prev_match = intval($_POST['prev_match_id']);
  $team_number = intval($_POST['team_number']);
  
  if ($team_number == 1) {
    PendingMatchesDatabase::update_match_team_1($match_id, $team_id);
  } else {
    PendingMatchesDatabase::update_match_team_2($match_id, $team_id);
  }

  $prev_match_info = PendingMatchesDatabase::get_match_by_id($prev_match);
  
  $result = MatchesDatabase::insert_match(
      $prev_match_info->tournament_id, 
      $prev_match_info->division_id, 
      $prev_match_info->bracket_id, 
      $prev_match_info->bracket_round,
      $prev_match_info->bracket_match, 
      $prev_match_info->field_number, 
      $prev_match_info->team_id_1, 
      $prev_match_info->team_id_2, 
      $prev_match_info->official_id === 0 ? null : $prev_match_info->official_id,
      $prev_match_info->match_date, 
      $prev_match_info->match_time, 
      null,
      null,
      $team_id);
  
  if(!$result) {
    $match_id = MatchesDatabase::get_match_by_bracket_match($prev_match_info->bracket_match, $prev_match_info->bracket_id)->match_id;
    $result = MatchesDatabase::update_match_winner(
      $match_id, 
      $team_id);
  }

  wp_send_json_success(['message' => 'Ganador actualizado correctamente']);
}

add_action('wp_ajax_update_match_winner', 'update_match_winner');
add_action('wp_ajax_nopriv_update_match_winner', 'update_match_winner');
add_action('wp_ajax_fetch_bracket_data', 'fetch_bracket_data');
add_action('wp_ajax_nopriv_fetch_bracket_data', 'fetch_bracket_data');
