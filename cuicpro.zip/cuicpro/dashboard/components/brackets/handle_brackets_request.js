jQuery(document).ready(function ($) {
	$("#brackets-dropdown").change(function () {
		const bracketID = $(this).val();

		$(".leader-line").remove();
		$("#brackets-data").off("scroll");

		if (bracketID !== "0") {
			$.ajax({
				type: "POST",
				url: cuicpro.ajax_url,
				data: {
					action: "fetch_bracket_data",
					bracket_id: bracketID,
				},
				success: function (response) {
					if (response.success) {
						const newElement = document.querySelector("#brackets-data");
						newElement.innerHTML = response.data.html;

						const elements = response.data.elements;
						$("#brackets-data").off("scroll");

						for (let i = elements.length - 1; i > 0; i--) {
							for (let match in elements[i]) {
								for (let j = 0; j < elements[i][match].length; j++) {
									const line = new LeaderLine(
										document.getElementById(elements[i][match][j]),
										document.getElementById(match),
										{
											color: "#000000",
											size: 2,
											endPlug: "behind",
											endPlugSize: 2,
											path: "grid",
											endSocket: "left",
											startSocket: "right",
										},
									);
									$("#brackets-data").on("scroll", function () {
										line.position();
									});
								}
							}
						}
					}
				},
				error: function (xhr, status, error) {
					console.error("Error:", error);
				},
			});
		} else {
			const element = document.querySelector("#brackets-data");
			element.innerHTML = "";
		}
	});
});

jQuery(document).on("change", "#team-winner", function () {
	const matchID = jQuery(this).data("match-id");
	const teamID = jQuery(this).val();
	const prevMatch = jQuery(this).data("prev-match");
	const teamNumber = jQuery(this).data("team-number");
	const bracket_id = jQuery("#brackets-dropdown").val();

	jQuery.ajax({
		type: "POST",
		url: cuicpro.ajax_url,
		data: {
			action: "update_match_winner",
			match_id: matchID,
			team_id: teamID,
			prev_match_id: prevMatch,
			team_number: teamNumber,
			bracket_id: bracket_id,
		},
		success: function (response) {
			console.log(response);
		},
		error: function (xhr, status, error) {
			console.error("Error:", error);
		},
	});
});
