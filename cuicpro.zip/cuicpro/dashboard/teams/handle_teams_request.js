jQuery(document).ready(function ($) {
	$("#divisions-dropdown-tv").change(function () {
		const divisionID = $(this).val();

		if (divisionID !== "0") {
			$.ajax({
				type: "POST",
				url: cuicpro.ajax_url,
				data: {
					action: "fetch_division_data",
					division_id: divisionID,
				},
				success: function (response) {
					if (response.success) {
						const newElement = document.querySelector("#division-data");
						newElement.innerHTML = response.data.html;
					} else {
						alert(response.data.message);
					}
				},
				error: function (xhr, status, error) {
					console.error("Error:", error);
				},
			});
		} else {
			const element = document.querySelector("#division-data");
			element.innerHTML = "";
		}
	});
});

jQuery(document).ready(function ($) {
	$("#coaches-dropdown-tv").change(function () {
		const coachID = $(this).val();

		if (coachID !== "0") {
			$.ajax({
				type: "POST",
				url: cuicpro.ajax_url,
				data: {
					action: "fetch_coach_data",
					coach_id: coachID,
				},
				success: function (response) {
					if (response.success) {
						const newElement = document.querySelector("#coach-data");
						newElement.innerHTML = response.data.html;
					} else {
						alert(response.data.message);
					}
				},
				error: function (xhr, status, error) {
					console.error("Error:", error);
				},
			});
		} else {
			const element = document.querySelector("#coach-data");
			element.innerHTML = "";
		}
	});
});

jQuery(document).on("click", "#delete-team-button-tv", function () {
	const teamID = jQuery(this).data("team-id");

	jQuery.ajax({
		type: "POST",
		url: cuicpro.ajax_url,
		data: {
			action: "delete_team",
			team_id: teamID,
		},
		success: function (response) {
			alert(response.data.message);
			if (response.success) {
				const element = document.querySelector(`#team-${teamID}`);
				element.remove();
			}
		},
		error: function (xhr, status, error) {
			console.error("Error:", error);
		},
	});
});

jQuery(document).on("click", "#add-team-button-tv", function (e) {
	e.preventDefault();

	const divisionID = jQuery("#team-division-ta").val();
	const teamName = jQuery("#team-name-ta").val();
	const teamCategory = jQuery("#team-category-ta").val();
	const teamMode = jQuery("#team-mode-ta").val();
	const coachID = jQuery("#coaches-dropdown-tv").val();
	const logo = jQuery("#team-logo-ta").val();

	if (teamName === "" || logo === "") {
		alert(
			"Agregar todos los datos del equipo, faltantes: " +
				(teamName === "" ? "Nombre, " : "") +
				(logo === "" ? "Logo" : ""),
		);
		return;
	}

	jQuery.ajax({
		type: "POST",
		url: cuicpro.ajax_url,
		data: {
			action: "add_team",
			division_id: divisionID,
			team_name: teamName,
			team_category: teamCategory,
			team_mode: teamMode,
			coach_id: coachID,
			logo: logo,
		},
		success: function (response) {
			if (response.success) {
				alert(response.data.message);
				const element = document.querySelector("#dynamic-input-team");
				const newElement = document.createElement("div");
				newElement.innerHTML = response.data.html;
				element.insertAdjacentElement("beforebegin", newElement);

				const inputName = document.querySelector("#team-name-ta");
				inputName.value = "";
				const inputLogo = document.querySelector("#team-logo-ta");
				inputLogo.value = "";
			} else {
				alert(response.data.message);
			}
		},
		error: function (xhr, status, error) {
			console.error("Error:", error);
		},
	});
});
