<?php

// function create_coaches_dropdown() {
//   $html = "";
//   $coaches = CoachesDatabase::get_coaches();
//   foreach ($coaches as $coach) {
//     $html .= "<option value='" . esc_attr($coach->coach_id) . "'>" . esc_html($coach->coach_name) . "</option>";
//   }
//   return $html;
// }

function on_add_team($team) {
  $team->team_mode = $team->team_mode === "1" ? "Varonil" : ($team->team_mode === "2" ? "Femenino" : "Mixto");
  $team->team_category = $team->team_category === "1" ? "5v5" : "7v7";
  $html = "";
  $logo = str_replace(" ", "-", $team->logo);
  $html .= "<div class='team-wrapper' id='team-$team->team_id'>";
  $html .= "<span class='team-cell'>" . esc_html($team->team_name) . "</span>";
  $html .= "<span class='team-cell'>" . esc_html($team->division_name) . "</span>";
  $html .= "<span class='team-cell'>" . esc_html($team->team_category) . "</span>";
  $html .= "<span class='team-cell'>" . esc_html($team->team_mode) . "</span>";
  $html .= "<div class='team-cell'>
              <img src='http://test.local/$logo'>
            </div>";
  $html .= "<div class='team-cell'>
              <button id='delete-team-button-tv' data-team-id=$team->team_id>Eliminar</button>
            </div>";
  $html .= "</div>";
  return $html;
}

function create_divisions_dropdown() {
  $html = "";
  $active_tournament = TournamentsDatabase::get_active_tournament();
  $divisions = DivisionsDatabase::get_divisions($active_tournament->tournament_id);
  foreach ($divisions as $division) {
    $html .= "<option value='" . esc_attr($division->division_id) . "'>" . esc_html($division->division_name) . "</option>";
  }
  return $html;
}

function create_dynamic_input_team() {
  $html = "";
  // dynamic input fields for adding teams
  $html .= "<div class='team-wrapper' id='dynamic-input-team'>";
  $html .= "<div class='team-input-cell'>
              <input type='text' id='team-name-ta' placeholder='Nombre'>
            </div>";
  $html .= "<div class='team-input-cell'>
              <select id='team-division-ta'>
                <option value='0'>Division Pendiente</option>
                " . create_divisions_dropdown() . "
              </select>
            </div>";
  $html .= "<div class='team-input-cell'>
              <select id='team-mode-ta'>
                <option value='1'>Masculino</option>
                <option value='2'>Femenino</option>
                <option value='3'>Mixto</option>
              </select>
            </div>";
  $html .= "<div class='team-input-cell'>
              <select id='team-category-ta'>
                <option value='1'>5v5</option>
                <option value='2'>7v7</option>
              </select>
            </div>";
  $html .= "<div class='team-input-cell'>
              <input type='text' id='team-logo-ta' placeholder='Logo'>
            </div>";
  $html .= "<div class='team-cell'>
              <button id='add-team-button-tv'>Agregar</button>
            </div>";
  $html .= "</div>";

  return $html;
}

function fetch_division_data() {
  if (!isset($_POST['division_id'])) {
    wp_send_json_error(['message' => 'No se pudo obtener los equipos']);
  }
  $division_id = intval($_POST['division_id']);
  $teams = TeamsDatabase::get_teams_by_division($division_id);

  // create table header
  $html = "<div class='teams-wrapper'>
            <div class='teams-header'>
              <span class='team-cell'>Equipo: </span>
              <span class='team-cell'>Entrenador: </span>
              <span class='team-cell'>Logo: </span>
              <span class='team-cell'>Acciones: </span>
            </div>
            ";

  // add team data to table
  foreach ($teams as $team) {
    $coach_name = CoachesDatabase::get_coach_by_id($team->coach_id)->coach_name;
    $logo = str_replace(" ", "-", $team->logo);
    $html .= "<div class='team-wrapper' id='team-$team->team_id'>";
    $html .= "<span class='team-cell'>" . esc_html($team->team_name) . "</span>";
    $html .= "<span class='team-cell'>" . esc_html($coach_name) . "</span>";
    $html .= "<div class='team-cell'>
                <img src='http://test.local/$logo'>
              </div>";
    $html .= "<div class='team-cell'>
                <button id='delete-team-button-tv' data-team-id=$team->team_id>Eliminar</button>
              </div>";
    $html .= "</div>";
  }

  wp_send_json_success(['html' => $html]);
}

function fetch_coach_data() {
  if (!isset($_POST['coach_id'])) {
    wp_send_json_error(['message' => 'No se pudo obtener los equipos']);
  }
  $coach_id = intval($_POST['coach_id']);
  $teams = TeamsDatabase::get_teams_by_coach($coach_id);

  // create table header
  $html = "<div class='teams-wrapper'>
            <div class='teams-header'>
              <span class='team-cell'>Equipo: </span>
              <span class='team-cell'>Division: </span>
              <span class='team-cell'>Categoria: </span>
              <span class='team-cell'>Modalidad: </span>
              <span class='team-cell'>Logo: </span>
              <span class='team-cell'>Acciones: </span>
            </div>
            ";

  // add team data to table
  foreach ($teams as $team) {
    if ($team->division_id === null) {
      $division_name = "Division Pendiente";
    } else {
      $division_name = DivisionsDatabase::get_division_by_id($team->division_id)->division_name;
    }
    $logo = str_replace(" ", "-", $team->logo);

    $team->team_category = $team->team_category === "1" ? "5v5" : "7v7";
    $team->team_mode = $team->team_mode === "1" ? "Masculino" : ($team->team_mode === "2" ? "Femenino" : "Mixto");

    $html .= "<div class='team-wrapper' id='team-$team->team_id'>";
    $html .= "<span class='team-cell'>" . esc_html($team->team_name) . "</span>";
    $html .= "<span class='team-cell'>" . esc_html($division_name) . "</span>";
    $html .= "<span class='team-cell'>" . esc_html($team->team_mode) . "</span>";
    $html .= "<span class='team-cell'>" . esc_html($team->team_category) . "</span>";
    $html .= "<div class='team-cell'>
                <img src='http://test.local/$logo'>
              </div>";
    $html .= "<div class='team-cell'>
                <button id='delete-team-button-tv' data-team-id=$team->team_id>Eliminar</button>
              </div>";
    $html .= "</div>";
  }

  $html .= create_dynamic_input_team();

  wp_send_json_success(['html' => $html]);
}

function delete_team() {
  if (!isset($_POST['team_id'])) {
    wp_send_json_error(['message' => 'No se pudo eliminar el equipo']);
  }
  $team_id = intval($_POST['team_id']);
  TeamsDatabase::delete_team($team_id);
  wp_send_json_success(['message' => 'Equipo eliminado correctamente']);
}

function add_team() {
  if (!isset($_POST['division_id']) || !isset($_POST['team_name']) || !isset($_POST['team_category']) || !isset($_POST['team_mode']) || !isset($_POST['coach_id']) || !isset($_POST['logo'])) {
    wp_send_json_error(['message' => 'Faltan datos']);
  }
  $team_name = sanitize_text_field($_POST['team_name']);
  $coach_id = intval($_POST['coach_id']);
  $division_id = intval($_POST['division_id']);
  if ($division_id == 0) {
    $division_id = null;
  }
  $team_category = intval($_POST['team_category']);
  $team_mode = intval($_POST['team_mode']);
  $logo = sanitize_text_field($_POST['logo']);
  
  $result = TeamsDatabase::insert_team($team_name, $division_id, $team_category, $team_mode, $coach_id, $logo);
  if ($result) {
    $team = TeamsDatabase::get_team_by_name($team_name, $division_id);
    $team->division_name = DivisionsDatabase::get_division_by_id($team->division_id)->division_name;
    $team->team_category = $team->team_category === "1" ? "5v5" : "7v7";
    $team->team_mode = $team->team_mode === "1" ? "Masculino" : ($team->team_mode === "2" ? "Femenino" : "Mixto");
    wp_send_json_success(['message' => 'Equipo agregado correctamente', 'html' => on_add_team($team)]);
  }
  wp_send_json_error(['message' => 'Equipo no agregado, equipo ya existe']);
}

add_action('wp_ajax_fetch_coach_data', 'fetch_coach_data');
add_action('wp_ajax_nopriv_fetch_coach_data', 'fetch_coach_data');
add_action('wp_ajax_fetch_division_data', 'fetch_division_data');
add_action('wp_ajax_nopriv_fetch_division_data', 'fetch_division_data');
add_action('wp_ajax_delete_team', 'delete_team');
add_action('wp_ajax_nopriv_delete_team', 'delete_team');
add_action('wp_ajax_add_team', 'add_team');
add_action('wp_ajax_nopriv_add_team', 'add_team');
