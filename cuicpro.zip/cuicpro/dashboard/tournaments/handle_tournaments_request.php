<?php

function generate_bracket_levels(int $total_teams) {
  $total_teams_4 = [1,2];
  $total_teams_8 = [1,2,4];
  $total_teams_16 = [1,2,4,8];
  $total_teams_32 = [1,2,4,8,16];

  if ($total_teams < 8) {
    $left_teams = $total_teams - 4;
    $brackets = $total_teams_4;

    $brackets[] = $left_teams;
    $reversed_brackets = array_reverse($brackets);
    return $reversed_brackets;
  }
  if ($total_teams < 16) {
    $left_teams = $total_teams - 8;
    $brackets = $total_teams_8;

    $brackets[] = $left_teams;
    $reversed_brackets = array_reverse($brackets);
    return $reversed_brackets;
  }
  if ($total_teams < 32) {
    $left_teams = $total_teams - 16;
    $brackets = $total_teams_16;

    $brackets[] = $left_teams;
    $reversed_brackets = array_reverse($brackets);
    return $reversed_brackets;
  }

  $left_teams = $total_teams - 32;
  $brackets = $total_teams_32;

  $brackets[] = $left_teams;
  $reversed_brackets = array_reverse($brackets);
  return $reversed_brackets;
}

function start_tournament() {
  if (!isset($_POST['tournament_id'])) {
    wp_send_json_error(['message' => 'No se pudo iniciar el torneo']);
  }
  // make selected tournament active
  $tournament_id = intval($_POST['tournament_id']);
  TournamentsDatabase::start_tournament($tournament_id);

  // tournament data schedule
  $days = ['Viernes', 'Sábado', 'Domingo'];
  $hours = ['14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00'];
  $hoursFull = ['08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00'];
  $schedule = [$days[0] => $hours, $days[1] => $hoursFull, $days[2] => $hoursFull];
  $fields5 = [1,2,3,4,5,6,7,8];
  $fields7 = [9,10,11,12];

  // create divisions brackets
  $divisions = DivisionsDatabase::get_divisions($tournament_id);
  if (!$divisions) {
    wp_send_json_error(['message' => 'No se pudo iniciar el torneo, no hay divisiones para el torneo']);
  }
  // verify if divisions have teams
  foreach ($divisions as $division) {
    $teams = TeamsDatabase::get_teams_by_division($division->division_id);
    if (!$teams) {
      wp_send_json_error(['message' => 'No se pudo iniciar el torneo, no hay equipos para la division ' . $division->division_name]);
    }
  }

  // create brackets for each division
  foreach ($divisions as $division) {
    BracketsDatabase::insert_bracket($tournament_id, $division->division_id);
  }

  $test = [];

  // create matches for each bracket
  foreach ($divisions as $division) {
    // get bracket and teams associated with division
    $bracket = BracketsDatabase::get_bracket_by_division($division->division_id, $tournament_id);
    $teams = TeamsDatabase::get_teams_by_division($division->division_id);
    $matches_per_hour = generate_bracket_levels(count($teams));
    $test[] = $matches_per_hour;
    $total_matches = array_sum($matches_per_hour);
    $match_count = 1;

    // poblate 5v5 matches
    if ($division->division_mode == 1) {
      foreach ($schedule as $day => $hours) {
        if ($match_count > $total_matches) {
          break;
        }
        foreach ($hours as $hour_key => $hour) {
          if ($match_count > $total_matches) {
            break;
          }
          $max_games = $matches_per_hour[$hour_key];
          $games_per_hour_counter = 0;
          foreach ($fields5 as $key => $field) {
            if ($match_count > $total_matches) {
              break;
            }
            PendingMatchesDatabase::insert_match(
              $tournament_id, 
              $division->division_id, 
              $bracket->bracket_id, 
              $field, 
              $day, 
              $hour, 
              $match_count,
              1
            );
            $match_count++;
            $games_per_hour_counter++;
            if ($games_per_hour_counter >= $max_games) {
              break;
            }
          }
        }
      }
    }
    
    // poblate 7v7 matches
    // if ($division->division_mode == 2) {
    //   foreach ($schedule as $day => $hours) {
    //     foreach ($hours as $hour) {
    //       foreach ($fields7 as $field) {
    //         foreach ($teams as $key => $team) {
    //           PendingMatchesDatabase::insert_match(
    //             $tournament_id, 
    //             $division->division_id, 
    //             $bracket->bracket_id, 
    //             $field, 
    //             $day, 
    //             $hour, 
    //             $key + 1,
    //             1
    //           );
    //         }
    //       }
    //     }
    //   }
    // }
  }

  wp_send_json_success(['message' => 'Torneo iniciado correctamente', 'test' => $test]);
}

function on_add_tournament($tournament) {
  $html = "";
  $html .= "<div class='tournament-wrapper' id='tournament-$tournament->tournament_id'>";
  $html .= "<span class='tournament-cell'>" . esc_html($tournament->tournament_name) . "</span>";
  $html .= "<span class='tournament-cell'>" . esc_html($tournament->tournament_is_active ? 'Sí' : 'No') . "</span>";
  $html .= "<div class='tournament-cell'>
              <button id='delete-tournament-button-cv' data-tournament-id=$tournament->tournament_id>Eliminar</button>
            </div>";
  $html .= "</div>";
  return $html;
}

function delete_tournament() {
  if (!isset($_POST['tournament_id'])) {
    wp_send_json_error(['message' => 'No se pudo eliminar el torneo']);
  }
  $tournament_id = intval($_POST['tournament_id']);
  TournamentsDatabase::delete_tournament($tournament_id);
  wp_send_json_success(['message' => 'Torneo eliminado correctamente']);
}

function add_tournament() {
  if (!isset($_POST['tournament_name'])) {
    wp_send_json_error(['message' => 'Faltan datos']);
  }
  $tournament_name = sanitize_text_field($_POST['tournament_name']);
  $tournament_creation_date = date('Y-m-d');
  $result = TournamentsDatabase::insert_tournament($tournament_name, $tournament_creation_date );
  if ($result) {
    $tournament = TournamentsDatabase::get_tournament_by_name($tournament_name);
    wp_send_json_success(['message' => 'Torneo agregado correctamente', 'html' => on_add_tournament($tournament)]);
  }
  wp_send_json_error(['message' => 'Torneo no agregado, torneo ya existe']);
}

add_action('wp_ajax_delete_tournament', 'delete_tournament');
add_action('wp_ajax_nopriv_delete_tournament', 'delete_tournament');
add_action('wp_ajax_add_tournament', 'add_tournament');
add_action('wp_ajax_nopriv_add_tournament', 'add_tournament');
add_action('wp_ajax_start_tournament', 'start_tournament');
add_action('wp_ajax_nopriv_start_tournament', 'start_tournament');
