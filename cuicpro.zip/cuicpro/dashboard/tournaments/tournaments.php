<?php

// function to display the dropdown of leagues to show teams
function create_dynamic_input_tournament() {
  $html = "";
  // dynamic input fields for adding teams
  $html .= "<div class='tournament-wrapper' id='dynamic-input-tournament'>";
  $html .= "<div class='tournament-input-cell'>
              <input type='text' id='tournament-name-cv' placeholder='Nombre'>
            </div>";
  $html .= "<div class='tournament-cell'>
              <button id='add-tournament-button-cv'>Agregar</button>
            </div>";
  $html .= "</div>";

  return $html;
}

function cuicpro_tournament_viewer() {
  $tournaments = TournamentsDatabase::get_tournaments();

  // create table header
  $html = "<div class='tournaments-wrapper'>
            <div class='tournaments-header'>
              <span class='tournament-cell'>Torneo:</span>
              <span class='tournament-cell'>¿Está Activo?</span>
              <span class='tournament-cell'>Acciones:</span>
            </div>
            ";

	if (count($tournaments) === 0) {
		$html .= "<div class='tournament-wrapper cell-hidden' id='tournament-data'></div>";
	}

  // add tournament data to table
  foreach ($tournaments as $tournament) {
		$is_active = $tournament->tournament_is_active ? true : false;
    $html .= "<div class='tournament-wrapper' id='tournament-$tournament->tournament_id'>";
    $html .= "<span class='tournament-cell'>" . esc_html($tournament->tournament_name) . "</span>";
    $html .= "<span class='tournament-cell " . esc_html($is_active ? 'active-tournament' : '') . "' data-tournament-id=$tournament->tournament_id>" . esc_html($is_active ? 'Sí' : 'No') . "</span>";
    $html .= "<div class='tournament-cell'>
                <button id='delete-tournament-button-cv' data-tournament-id=$tournament->tournament_id>Eliminar</button>
                <button id='start-tournament-button-cv' data-tournament-id=$tournament->tournament_id>Iniciar</button>
              </div>";
    $html .= "</div>";
  }

  $html .= create_dynamic_input_tournament();
  $html .= "</div>";

  echo $html;
}


// function to register the dashboard widget
function tournaments_dashboard_widgets() {
	// Register your custom WordPress admin dashboard widget
	wp_add_dashboard_widget('cuicpro_tournaments_widget', 'CUICPRO Torneos', 'cuicpro_tournament_viewer');
}

// hooks up your code to dashboard setup
add_action('wp_dashboard_setup', 'tournaments_dashboard_widgets');

// enqueue scripts related to this file
function enqueue_tournaments_scripts() {
	wp_enqueue_style( 'tournaments-styles', plugins_url('/styles.css', __FILE__) );
	wp_enqueue_script(
			'tournaments-script',
			plugins_url('/handle_tournaments_request.js', __FILE__),
			array('jquery'),
			null,
			true
	);

	// Pass the AJAX URL to JavaScript
	wp_localize_script('tournaments-script', 'cuicpro', array(
			'ajax_url' => admin_url('admin-ajax.php')
	));
}
add_action('admin_enqueue_scripts', 'enqueue_tournaments_scripts');

require_once __DIR__ . '/handle_tournaments_request.php';