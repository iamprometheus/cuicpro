jQuery(document).on("click", "#delete-tournament-button-cv", function () {
	const tournamentID = jQuery(this).data("tournament-id");

	jQuery.ajax({
		type: "POST",
		url: cuicpro.ajax_url,
		data: {
			action: "delete_tournament",
			tournament_id: tournamentID,
		},
		success: function (response) {
			alert(response.data.message);
			if (response.success) {
				const element = document.querySelector(`#tournament-${tournamentID}`);
				element.remove();
			}
		},
		error: function (xhr, status, error) {
			console.error("Error:", error);
		},
	});
});

jQuery(document).on("click", "#add-tournament-button-cv", function (e) {
	e.preventDefault();

	const tournamentName = jQuery("#tournament-name-cv").val();

	if (tournamentName === "") {
		alert("Agregar Nombre");
		return;
	}

	jQuery.ajax({
		type: "POST",
		url: cuicpro.ajax_url,
		data: {
			action: "add_tournament",
			tournament_name: tournamentName,
		},
		success: function (response) {
			alert(response.data.message);
			if (response.success) {
				const tournamentData = document.querySelector("#tournament-data");
				tournamentData.classList.remove("cell-hidden");
				tournamentData.insertAdjacentHTML("beforeend", response.data.html);

				// clear inputs from table
				const inputName = document.querySelector("#tournament-name-cv");
				inputName.value = "";
			}
		},
		error: function (xhr, status, error) {
			console.error("Error:", error);
		},
	});
});

jQuery(document).on("click", "#start-tournament-button-cv", function (e) {
	e.preventDefault();
	const tournamentID = jQuery(this).data("tournament-id");

	jQuery.ajax({
		type: "POST",
		url: cuicpro.ajax_url,
		data: {
			action: "start_tournament",
			tournament_id: tournamentID,
		},
		success: function (response) {
			console.log(response.data);
		},
		error: function (xhr, status, error) {
			console.error("Error:", error);
		},
	});
});
