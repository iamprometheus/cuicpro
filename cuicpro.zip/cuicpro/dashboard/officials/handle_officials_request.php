<?php
function delete_official() {
  if (!isset($_POST['official_id'])) {
    wp_send_json_error(['message' => 'No se pudo eliminar el arbitro']);
  }
  if (OfficialsDatabase::get_official_by_id(intval($_POST['official_id']))) {
    wp_send_json_error(['message' => 'No se pudo eliminar el arbitro, hay equipos asociados']);
  }
  $official_id = intval($_POST['official_id']);
  OfficialsDatabase::delete_official($official_id);
  wp_send_json_success(['message' => 'Arbitro eliminado correctamente']);
}

function add_official() {
  if (!isset($_POST['official_name']) || !isset($_POST['official_time']) || !isset($_POST['official_schedule']) || !isset($_POST['official_mode']) || !isset($_POST['official_team_id']) || !isset($_POST['official_city']) || !isset($_POST['official_state']) || !isset($_POST['official_country'])) {
    wp_send_json_error(['message' => 'Faltan datos']);
  }
  $official_name = sanitize_text_field($_POST['official_name']);
  $official_time = sanitize_text_field($_POST['official_time']);
  $official_schedule = sanitize_text_field($_POST['official_schedule']);
  $official_mode = sanitize_text_field($_POST['official_mode']);
  $official_team_id = sanitize_text_field($_POST['official_team_id']);
  $official_city = sanitize_text_field($_POST['official_city']);
  $official_state = sanitize_text_field($_POST['official_state']);
  $official_country = sanitize_text_field($_POST['official_country']);
  $result = OfficialsDatabase::insert_official($official_name, $official_time, $official_schedule, $official_mode, $official_team_id, $official_city, $official_state, $official_country);
  if ($result) {
    $official = OfficialsDatabase::get_official_by_name($official_name);
    wp_send_json_success(['message' => 'Arbitro agregado correctamente', 'official' => $official]);
  }
  wp_send_json_error(['message' => 'Arbitro no agregado, arbitro ya existe']);
}

add_action('wp_ajax_delete_official', 'delete_official');
add_action('wp_ajax_nopriv_delete_official', 'delete_official');
add_action('wp_ajax_add_official', 'add_official');
add_action('wp_ajax_nopriv_add_official', 'add_official');
