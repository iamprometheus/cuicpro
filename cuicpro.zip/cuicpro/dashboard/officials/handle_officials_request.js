jQuery(document).on("click", "#add-official-button-cv", function (e) {
	e.preventDefault();

	const officialName = jQuery("#official-name-cv").val();
	const officialTime = jQuery("#official-time-cv").val();

	const officialSchedule = [];
	jQuery("#official-schedule-cv").each(function () {
		if (jQuery(this).is(":checked")) {
			officialSchedule.push(jQuery(this).val());
		}
	});
	const officialMode = jQuery("#official-mode-cv").val();
	const officialTeamId = jQuery("#official-team-id-cv").val();
	const officialCity = jQuery("#official-city-cv").val();
	const officialState = jQuery("#official-state-cv").val();
	const officialCountry = jQuery("#official-country-cv").val();

	if (officialName === "") {
		alert("Agregar un nombre al arbitro");
		return;
	}

	if (officialTime === "") {
		alert("Agregar las horas al arbitro");
		return;
	}

	if (officialSchedule.length === 0) {
		alert("Agregar al menos un dia al arbitro");
		return;
	}

	if (officialCity === "" || officialState === "" || officialCountry === "") {
		alert("Agregar la ciudad, estado y pais del arbitro");
		return;
	}

	console.log(
		officialSchedule,
		officialName,
		officialTime,
		officialMode,
		officialTeamId,
		officialCity,
		officialState,
		officialCountry,
	);

	jQuery.ajax({
		type: "POST",
		url: cuicpro.ajax_url,
		data: {
			action: "add_official",
			official_name: officialName,
			official_time: officialTime,
			official_schedule: officialSchedule.join(","),
			official_mode: officialMode,
			official_team_id: officialTeamId,
			official_city: officialCity,
			official_state: officialState,
			official_country: officialCountry,
		},
		success: function (response) {
			if (response.success) {
				alert(response.data.message);

				// add official to the table
				const element = document.querySelector("#dynamic-input-official");
				const newElement = document.createElement("div");
				newElement.innerHTML = `
				<div class="official-wrapper" id="official-${response.data.official.official_id}">
					<span class="official-cell">${response.data.official.official_name}</span>
					<span class="official-cell">${response.data.official.official_time}</span>
					<span class="official-cell">${response.data.official.official_schedule}</span>
					<span class="official-cell">${response.data.official.official_mode}</span>
					<span class="official-cell">${response.data.official.official_team_id}</span>
					<span class="official-cell">${response.data.official.official_city}</span>
					<span class="official-cell">${response.data.official.official_state}</span>
					<span class="official-cell">${response.data.official.official_country}</span>
				<div class="team-cell">	
					<button id="delete-official-button-cv" data-official-id="${response.data.official.official_id}">Eliminar</button>
				</div></div>
				`;
				element.insertAdjacentElement("beforebegin", newElement);

				const inputName = document.querySelector("#official-name-cv");
				inputName.value = "";
				const inputTime = document.querySelector("#official-time-cv");
				inputTime.value = "";
				const inputSchedule = document.querySelectorAll(
					"#official-schedule-cv",
				);
				inputSchedule.forEach((input) => {
					input.checked = false;
				});
				const inputMode = document.querySelector("#official-mode-cv");
				inputMode.value = "";
				const inputTeamId = document.querySelector("#official-team-id-cv");
				inputTeamId.value = "";
				const inputCity = document.querySelector("#official-city-cv");
				inputCity.value = "";
				const inputState = document.querySelector("#official-state-cv");
				inputState.value = "";
				const inputCountry = document.querySelector("#official-country-cv");
				inputCountry.value = "";

				// update officials dropdown from team by league viewer
				const dropdown = document.querySelector("#team-official-ta");
				if (dropdown) {
					dropdown.innerHTML += `<option value="${response.data.official.official_id}">${response.data.official.official_name}</option>`;
				}

				// update officials dropdown from teams by official viewer
				const dropdown2 = document.querySelector("#officials-dropdown-tv");
				dropdown2.innerHTML += `<option value="${response.data.official.official_id}">${response.data.official.official_name}</option>`;
			} else {
				alert(response.data.message);
			}
		},
		error: function (xhr, status, error) {
			console.error("Error:", error);
		},
	});
});

jQuery(document).on("click", "#delete-official-button-cv", function () {
	const officialID = jQuery(this).data("official-id");

	jQuery.ajax({
		type: "POST",
		url: cuicpro.ajax_url,
		data: {
			action: "delete_official",
			official_id: officialID,
		},
		success: function (response) {
			alert(response.data.message);
			if (response.success) {
				const parent = document
					.querySelector(`#official-${officialID}`)
					.closest("div");
				parent.remove();

				// remove option from teams by league viewer dropdown
				const dropdown = document.querySelector("#team-official-ta");
				if (dropdown) {
					dropdown.querySelector(`option[value="${officialID}"]`).remove();
				}

				// remove option from teams by coach viewer dropdown
				const dropdown2 = document.querySelector("#officials-dropdown-tv");
				dropdown2.querySelector(`option[value="${officialID}"]`).remove();
				const element = document.querySelector("#official-data");
				element.innerHTML = "";
			}
		},
		error: function (xhr, status, error) {
			console.error("Error:", error);
		},
	});
});
