<?php

function render_teams() {
  $teams = TeamsDatabase::get_teams();
  $html = "";

  $html .= "<option value='0'>Ninguno</option>";
  foreach ($teams as $team) {
    $html .= "<option value='" . $team->team_id . "'>" . $team->team_name . "</option>";
  }
  return $html;
}

function create_dynamic_input_official() {
  $html = "";
  // dynamic input fields for adding teams
  $html .= "<div class='official-wrapper' id='dynamic-input-official'>";
  $html .= "<div class='official-input-cell'>
              <input type='text' id='official-name-cv' placeholder='Nombre'>
            </div>";
            
  $html .= "<div class='official-input-cell'>
              <input type='number' min='1' max='12' id='official-time-cv' placeholder='Horas' required>
            </div>";
  $html .= "<div class='official-input-cell'>
              <div>
                  <input type='checkbox' value='Viernes' id='official-schedule-cv'/>
                  <label for='official-schedule-cv'>Viernes</label>
              </div>
              <div>
                  <input type='checkbox' value='Sabado' id='official-schedule-cv'/>
                  <label for='official-schedule-cv'>Sabado</label>
              </div>
              <div>
                  <input type='checkbox' value='Domingo' id='official-schedule-cv'/>
                  <label for='official-schedule-cv'>Domingo</label>
              </div>
            </div>";
  $html .= "<div class='official-input-cell'>
              <select id='official-mode-cv'>
                <option value='5v5'>5v5</option>
                <option value='7v7'>7v7</option>
                <option value='ambos'>Ambos</option>
              </select>
            </div>";
  $html .= "<div class='official-input-cell'>
              <select id='official-team-id-cv'>
                " . render_teams() . "
              </select>
            </div>";
  $html .= "<div class='official-input-cell'>
              <input type='text' id='official-city-cv' placeholder='Ciudad'>
            </div>";
  $html .= "<div class='official-input-cell'>
              <input type='text' id='official-state-cv' placeholder='Estado'>
            </div>";
  $html .= "<div class='official-input-cell'>
              <input type='text' id='official-country-cv' placeholder='Pais'>
            </div>";
  $html .= "<div class='official-cell'>
              <button id='add-official-button-cv'>Agregar</button>
            </div>";
  $html .= "</div>";

  return $html;
}

function cuicpro_official_viewer() {
  $officials = OfficialsDatabase::get_officials();

  // create table header
  $html = "<div class='officials-wrapper'>
            <div class='officials-header'>
              <span class='official-cell'>Nombre: </span>
              <span class='official-cell'>Horas: </span>
              <span class='official-cell'>Dias: </span>
              <span class='official-cell'>Modo: </span>
              <span class='official-cell'>Equipo: </span>
              <span class='official-cell'>Ciudad: </span>
              <span class='official-cell'>Estado: </span>
              <span class='official-cell'>Pais: </span>
              <span class='official-cell'>Acciones: </span>
            </div>
            ";

  // add team data to table
  foreach ($officials as $official) {
    $html .= "<div class='official-wrapper' id='official-$official->official_id'>";
    $html .= "<span class='official-cell'>" . esc_html($official->official_name) . "</span>";
    $html .= "<span class='official-cell'>" . esc_html($official->official_time) . "</span>";
    $html .= "<span class='official-cell'>" . esc_html($official->official_schedule) . "</span>";
    $html .= "<span class='official-cell'>" . esc_html($official->official_mode) . "</span>";
    $html .= "<span class='official-cell'>" . esc_html($official->official_team_id) . "</span>";
    $html .= "<span class='official-cell'>" . esc_html($official->official_city) . "</span>";
    $html .= "<span class='official-cell'>" . esc_html($official->official_state) . "</span>";
    $html .= "<span class='official-cell'>" . esc_html($official->official_country) . "</span>";
    $html .= "<div class='official-cell'>
                <button id='delete-official-button-cv' data-official-id=$official->official_id>Eliminar</button>
              </div>";
    $html .= "</div>";
  }

  $html .= create_dynamic_input_official();
  $html .= "</div>";

  echo $html;
}


// function to register the dashboard widget
function officials_dashboard_widgets() {
	// Register your custom WordPress admin dashboard widget
	wp_add_dashboard_widget('cuicpro_officials_widget', 'CUICPRO Arbitros', 'cuicpro_official_viewer');
}

// hooks up your code to dashboard setup
add_action('wp_dashboard_setup', 'officials_dashboard_widgets');

// enqueue scripts related to this file
function enqueue_official_scripts() {
	wp_enqueue_style( 'officials-styles', plugins_url('/styles.css', __FILE__) );
	wp_enqueue_script(
			'official-script',
			plugins_url('/handle_officials_request.js', __FILE__),
			array('jquery'),
			null,
			true
	);

	// Pass the AJAX URL to JavaScript
	wp_localize_script('official-script', 'cuicpro', array(
			'ajax_url' => admin_url('admin-ajax.php')
	));
}
add_action('admin_enqueue_scripts', 'enqueue_official_scripts');

require_once __DIR__ . '/handle_officials_request.php';